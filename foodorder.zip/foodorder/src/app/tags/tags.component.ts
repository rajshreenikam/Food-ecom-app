import { Component, Input, OnInit } from '@angular/core';
import { tag } from '../shared/Models/tag';
import { FoodService } from '../services/food/food.service';

@Component({
  selector: 'app-tags',
  templateUrl: './tags.component.html',
  styleUrls: ['./tags.component.css']
})
export class TagsComponent implements OnInit {
  @Input()foodpageTags?:string[];
  @Input()justifyContent:string = 'center';
  tags?:tag[]=[];
  constructor( private fs:FoodService){ }

  ngOnInit(){
    if(!this.foodpageTags)
    this.tags=this.fs.getAllTag()
  }

}
