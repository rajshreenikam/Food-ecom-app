import { Injectable } from '@angular/core';
import { foods } from 'src/app/shared/Models/food';
import { tag } from 'src/app/shared/Models/tag';
@Injectable({
  providedIn: 'root'
})
export class FoodService {

  constructor() { /* TODO document why this constructor is empty */  }

  getFoodById(id:number):foods{
    return this.getAll().find(food=>food.id==id)!;
  }
  
  getAllFoodByTag(tag:string):foods[]{
    return tag =="All"?
    this.getAll():this.getAll().filter(food=>food.tags?.includes(tag))
  }

  getAllTag():tag[]{
  return[
    {name:'All',count:14},
    {name:'FastFood',count:4},
    {name:'Pizza',count:2},
    {name:'Lunch',count:3},
    {name:'SlowFood',count:1},
    {name:'Hamburger',count:1},
    {name:'Fry',count:1},
    {name:'soup',count:1},

    
  ]

 }
  getAll():foods[]{
     return[
      {
        id:1,
        name:'Pizza pepperoin',
        cookTime:'10-20',
        price:10,
        favorite:false,
        origins:['Italy'],
        star:2,
        imageUrl:'/assets/images/food-1.jpg',
        tags:['FastFood','Pizza','Lunch'],
      },
      {
        id:2, 
        name:'MeatBall',
        cookTime:'20-30',
        price:20,
        favorite:true,
        origins:['persia','middle east','china'],
        star:4.7,
        imageUrl:'/assets/images/food-2.jpg',
        tags:['SlowFood','Lunch'],
      },
      {
        id:3,
        name:'Hamburger',
        cookTime:'10-15',
        price:5,
        favorite:true,
        origins:['Belgium','France'],
        star:3.3,
        imageUrl:'/assets/images/food-3.jpg',
        tags:['FastFood','Hamburger'],
      },
      {
        id:4,
        name:'Fried Potatoes',
        cookTime:'15-20',
        price:2,
        favorite:true,
        origins:['germany','US'],
        star:3.3,
        imageUrl:'/assets/images/food-4.jpg',
        tags:['FastFood','Fry'],
      },
      {
        id:5,
        name:' Chicken Soup',
        cookTime:'40-50',
        price:11,
        favorite:false,
        origins:['India','Asia'],
        star:3.0,
        imageUrl:'/assets/images/food-5.jpg',
        tags:['FastFood','Pizza','Lunch'],
      },
      {
        id:6,
        name:'Vegetables Pizza',
        cookTime:'40-50',
        price:9,
        favorite:false,
        origins:['Italy'],
        star:4.0,
        imageUrl:'/assets/images/food-6.jpg',
        tags:['FastFood','Lunch'],
      }
    ]
      }  
  }

